#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

char get_player_choice(int player_num);
void determine_winner(char p1, char p2, int *p1_score, int *p2_score);
void print_choice_name(char choice);
void clear_screen();

int main() {
    char p1_choice, p2_choice;
    char play_again;
    
    int p1_score = 0;
    int p2_score = 0;
    int round_count = 1;

    clear_screen();
    printf("=========================================\n");
    printf("     2-Player Rock, Paper, Scissors!    \n");
    printf("=========================================\n");

    do 
    {
        printf("\n--- Round %d ---\n", round_count);
        printf("Current Score -> Player 1: %d | Player 2: %d\n\n", p1_score, p2_score);

        p1_choice = get_player_choice(1);
        p2_choice = get_player_choice(2);

        clear_screen();
        printf("=========================================\n");
        printf("             ROUND RESULTS               \n");
        printf("=========================================\n");
        
        printf("Player 1 chose: ");
        print_choice_name(p1_choice);
        printf("\nPlayer 2 chose: ");
        print_choice_name(p2_choice);
        printf("\n\n");

        determine_winner(p1_choice, p2_choice, &p1_score, &p2_score);
        round_count++;

        printf("\nDo you want to play another round? (y/n): ");
        scanf(" %c", &play_again);
        play_again = tolower(play_again);
        clear_screen();

    } while (play_again == 'y');
    printf("=========================================\n");
    printf("               GAME OVER                 \n");
    printf("=========================================\n");
    printf("Final Score -> Player 1: %d | Player 2: %d\n", p1_score, p2_score);

    if (p1_score > p2_score)
    {
        printf("\n==> Player 1 wins the entire match!\n");
    }
    else if (p2_score > p1_score) 
    {
        printf("\n==> Player 2 wins the entire match!\n");
    } 
    else
    {
        printf("\n==> The overall match ended in a tie draw!\n");
    }

    printf("Thank you for playing!\n");
    return 0;
}
char get_player_choice(int player_num) {
    char choice;
    while (1) 
    {
        printf("Player %d - Enter [r]ock, [p]aper, or [s]cissors: ", player_num);
        scanf(" %c", &choice);
        choice = tolower(choice);

        if (choice == 'r' || choice == 'p' || choice == 's') 
        {
            clear_screen();
            return choice; 
        }
        
        printf("Invalid choice! Please input 'r', 'p', or 's'.\n\n");
        while (getchar() != '\n'); // Purge buffer
    }
}
void determine_winner(char p1, char p2, int *p1_score, int *p2_score) {
    if (p1 == p2)
    {
        printf("==> It's a draw tie round!\n");
        return;
    }


    if ((p1 == 'r' && p2 == 's') ||
        (p1 == 'p' && p2 == 'r') ||
        (p1 == 's' && p2 == 'p')) {
        printf("==> Player 1 wins this round!\n");
        (*p1_score)++;
    }
    else 
    {
        printf("==> Player 2 wins this round!\n");
        (*p2_score)++;
    }
}
void print_choice_name(char choice) {
    if (choice == 'r') printf("Rock");
    else if (choice == 'p') printf("Paper");
    else if (choice == 's') printf("Scissors");
}
void clear_screen() 
{
    printf("\033[H\033[J"); 
}
