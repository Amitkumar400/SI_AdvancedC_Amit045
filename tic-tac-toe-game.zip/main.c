#include <stdio.h>
#include <stdlib.h>
#include <time.h>

char board[10] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};


void draw_board();
int check_winner();
int find_winning_or_blocking_move(char target_symbol);
int get_computer_move();

int main() {
    int player_turn = 1; 
    int choice, move, game_status;

   
    srand(time(NULL));

    do {
        draw_board();

        if (player_turn == 1) {
            
            printf("Your turn (X). Enter a position (1-9): ");
            if (scanf("%d", &choice) != 1) {
                printf("Invalid character! Enter numbers only.\n");
                while (getchar() != '\n'); 
                continue;
            }

            if (choice >= 1 && choice <= 9 && board[choice] == '0' + choice) 
            {
                board[choice] = 'X';
                player_turn = 0; 
            } 
            
            else 
            {
                printf("Invalid move! Try again.\n");
                while (getchar() != '\n'); getchar();
            }
        } 
        else
        {
            
            printf("Computer (O) is thinking...\n");
            move = get_computer_move();
            board[move] = 'O';
            player_turn = 1; 
        }

        game_status = check_winner();

    }
    while (game_status == -1);

    draw_board();


    if (game_status == 1)
    {
       
        if (player_turn == 0)
        {
            printf("==> Congratulations! You beat the computer!\n");
        } 
        else 
        {
            printf("==> The computer wins! Better luck next time.\n");
        }
    }
    else
    {
        printf("==> It's a draw game!\n");
    }

    return 0;
}

void draw_board()
{
    printf("\033[H\033[J"); 
    printf("\n   Tic-Tac-Toe: Human vs AI\n");
    printf("===============================\n\n");
    printf("     |     |     \n");
    printf("  %c  |  %c  |  %c  \n", board[1], board[2], board[3]);
    printf("_____|_____|_____\n");
    printf("     |     |     \n");
    printf("  %c  |  %c  |  %c  \n", board[4], board[5], board[6]);
    printf("_____|_____|_____\n");
    printf("     |     |     \n");
    printf("  %c  |  %c  |  %c  \n", board[7], board[8], board[9]);
    printf("     |     |     \n\n");
}


int find_winning_or_blocking_move(char target_symbol)
{
   
    int lines[8][3] =
    {
        {1, 2, 3}, {4, 5, 6}, {7, 8, 9}, 
        {1, 4, 7}, {2, 5, 8}, {3, 6, 9}, 
        {1, 5, 9}, {3, 5, 7}    
    };

    for (int i = 0; i < 8; i++) 
    {
        int a = lines[i][0];
        int b = lines[i][1];
        int c = lines[i][2];

        if (board[a] == target_symbol && board[b] == target_symbol && board[c] == '0' + c) return c;
        if (board[a] == target_symbol && board[c] == target_symbol && board[b] == '0' + b) return b;
        if (board[b] == target_symbol && board[c] == target_symbol && board[a] == '0' + a) return a;
    }
    return 0; 
}


int get_computer_move() {
    int move;

    
    move = find_winning_or_blocking_move('O');
    if (move != 0) return move;


    move = find_winning_or_blocking_move('X');
    if (move != 0) return move;


    if (board[5] == '5') return 5;


    int available_moves[9];
    int count = 0;
    for (int i = 1; i <= 9; i++)
    
    {
        if (board[i] == '0' + i)
        {
            available_moves[count++] = i;
        }
    }
    return available_moves[rand() % count];
}

int check_winner() {
    if (board[1] == board[2] && board[2] == board[3]) return 1;
    if (board[4] == board[5] && board[5] == board[6]) return 1;
    if (board[7] == board[8] && board[8] == board[9]) return 1;
    if (board[1] == board[4] && board[4] == board[7]) return 1;
    if (board[2] == board[5] && board[5] == board[8]) return 1;
    if (board[3] == board[6] && board[6] == board[9]) return 1;
    if (board[1] == board[5] && board[5] == board[9]) return 1;
    if (board[3] == board[5] && board[5] == board[7]) return 1;

    for (int i = 1; i <= 9; i++) {
        if (board[i] == '0' + i) return -1;
    }
    return 0; 
}
